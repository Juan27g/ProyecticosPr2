package co.edu.uniquindio.projectparcial2.patrones.Composite;

public interface ICompositeObjeto {
    void show();
}
