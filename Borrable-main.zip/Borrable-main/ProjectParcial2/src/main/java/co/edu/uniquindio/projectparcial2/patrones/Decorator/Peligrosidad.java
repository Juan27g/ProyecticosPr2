package co.edu.uniquindio.projectparcial2.patrones.Decorator;

public enum Peligrosidad {
    POCO,MEDIO,MUCHO;
}
