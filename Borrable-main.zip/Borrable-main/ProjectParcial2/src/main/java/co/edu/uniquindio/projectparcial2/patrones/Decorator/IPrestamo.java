package co.edu.uniquindio.projectparcial2.patrones.Decorator;

public interface IPrestamo {
    String getNumPrestamos();
    String getFechaPrestamo();
    String getDescripcion();
}
