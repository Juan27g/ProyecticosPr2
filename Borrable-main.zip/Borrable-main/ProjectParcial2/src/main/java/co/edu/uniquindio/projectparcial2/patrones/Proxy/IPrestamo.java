package co.edu.uniquindio.projectparcial2.patrones.Proxy;

public interface IPrestamo {
    void mostrarPrestamos();
    void registrarAccesos();
}
