package co.edu.uniquindio.projectparcial2.patrones.Bridge.implementacion;

import co.edu.uniquindio.projectparcial2.patrones.Bridge.Prestamo;

public interface IMetodoEntrega {
    void procesarPedido(Prestamo prestamo);
}
